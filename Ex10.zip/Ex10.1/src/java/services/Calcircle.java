/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author DELL
 */
@WebService(serviceName = "Calcircle")
public class Calcircle {

    @WebMethod(operationName = "findcirclrarea")
    public double findcirclrarea(@WebParam(name = "radius") double radius) {
        double circlearea = (radius*radius)*3.14;
        return circlearea;
    }

    @WebMethod(operationName = "callinecircle")
    public double callinecircle(@WebParam(name = "radius") double radius) {
        double LineCircle = 2*3.14*radius;
        return LineCircle;
    }
}
